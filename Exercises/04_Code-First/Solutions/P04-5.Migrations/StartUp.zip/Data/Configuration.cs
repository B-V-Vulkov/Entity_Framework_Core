﻿namespace P03_SalesDatabase.Data
{
    public abstract class Configuration
    {
        public const string ConnectionString = "Server=.;Database=SalesDb;Integrated Security=True;";
    }
}
