﻿namespace P01_HospitalDatabase
{
    using System;

    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
