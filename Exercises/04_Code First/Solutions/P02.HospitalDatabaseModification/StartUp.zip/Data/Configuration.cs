﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server=.;Database=Hospital;Integrated Security=True;";
    }
}
