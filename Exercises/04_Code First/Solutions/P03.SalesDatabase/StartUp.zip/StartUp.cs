﻿namespace P03_SalesDatabase
{
    using Data;

    public class StartUp
    {
        static void Main()
        {

        }
    }
}
