﻿namespace P01_StudentSystem.Data
{
    public abstract class DataConfiguration
    {
        public const string ConnectionString = "Server=.;Database=StudentSystemDb;Integrated Security=True;";
    }
}