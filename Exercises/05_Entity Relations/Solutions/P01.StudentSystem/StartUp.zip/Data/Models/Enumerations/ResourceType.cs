﻿namespace P01_StudentSystem.Data.Models.Enumerations
{
    public enum ResourceType
    {
        Other = 0,
        Video = 1,
        Presentation = 2,
        Document = 3,
    }
}
