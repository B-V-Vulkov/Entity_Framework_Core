﻿namespace P01_StudentSystem 
{
    using Microsoft.EntityFrameworkCore;

    using Data;

    public class StartUp
    {
        public static void Main()
        {
            
        }
    }
}
