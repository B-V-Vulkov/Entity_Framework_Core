﻿namespace SoftUni
{
    using System;
    using Data;
    using Models;

    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
